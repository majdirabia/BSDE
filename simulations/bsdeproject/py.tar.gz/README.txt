Look setbasis in regression.py
