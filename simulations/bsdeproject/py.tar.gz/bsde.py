import engine
import termstructure
import product 
import process
from regression import polyregression
from numpy import zeros, arange, linalg, average, std
import copy
from math import sqrt
class SelfFinancingBSDE(engine.SimulationEngine):
    def __init__(self, vProcess, product,time, snum):
        engine.SimulationEngine.__init__(self, vProcess,time, snum)
        _pnum = self.pnum
        self.pd = product
        self.Z = engine.zeros([snum, _pnum])
        self.Y = engine.zeros(snum)
    # This is the discounted process of
    # self financing strategy
    def generator(self, t):
        return zeros(self.snum)

    # If it is plain vanila self-financing
    # this function is describing only the terminal
    # payoff. If it is XVA bSDE,
    # this is cashflow + collateral
    def addedvalue(self, t):
        ret = zeros(self.snum)
        for i in range(0, self.snum):
            ret[i] = self.pd.payoff(self.time[t],self.path[t][i])
        return ret

    # The main backward iteration in BSDE
    def biteration(self):    
        _tnum = self.tnum
        _snum = self.snum
        _pnum = self.pnum
        # term structure 
        ts = self.vProcess.listProcess[0].ts 

        # discountfactor 
        dsf = ts.discountfactor(self.time[_tnum-1])
        # Backward iteration below, as the name is
        tdata=zeros(_snum)
        ppath=zeros(_snum)
        
        for t in range(_tnum-1, 0, -1):
            # dsf: discountfactor
            dsf = ts.discountfactor(self.time[t])
            dt = self.time[t]-self.time[t-1]
            # Last path is referred here
            self.Y = self.Y+dsf*self.addedvalue(t)
            # input data for the regrassion in the following step
            ppath=self.path[t-1]
            for p in range(0, _pnum):
                # tdata := y(i+1)*dw(i+1)
                # Be careful about the index t here
                tdata= self.Y * self.randomarray[t,:,p]/dt
                regr = polyregression(ppath, tdata, 2)
                regr.setbasis()
                # Here, self.Z = z(t-1)
                # Note the path index
                self.Z[:,p]=regr.evalarray(ppath)
            # s iter. set y
            # self.Y := y(t-1)
            tdata = self.Y + self.generator(t)*dt
            regr = polyregression(ppath, tdata,2)
            regr.setbasis()
            self.Y = regr.evalarray(ppath)

        self.y = average(self.Y)
        self.z = zeros(_pnum)
        for p in range(0, _pnum):
            self.z[p] = average(self.Y *
                    self.randomarray[0,:,p])/self.time[0]

# making target data in bsde

##############################
for n in range(1, 5):
    #  setting product information
    maturity = 0.5
    timegridn = 10*n

    dt = maturity / timegridn
    time = arange(dt, maturity+dt, dt)
    snum = 500
    #  parameters
    xprice = 1.05
    parameters1 ={'initialvalue': 1.,'volatility': 0.2}  
    parameters2 ={'initialvalue': 1.5,'volatility': 0.1}  
    ts=termstructure.TermStructure(0.01)
    # process
    s1 = process.BaseGBM(parameters1, ts)
    s2 = process.BaseGBM(parameters2, ts)
    co = [[0.5, 0.1], [0.1, 0.5]]
    vp = process.VProcess([s1])
    # product
    calloption = product.CallOption(maturity, xprice)
    firstbsde =SelfFinancingBSDE(vp, calloption, time, snum)
    firstbsde.biteration()
    print 'timegrid', 10*n
    print firstbsde.y, firstbsde.z
    print "-------------------"
