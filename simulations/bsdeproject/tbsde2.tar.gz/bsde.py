import engine
import termstructure
import product 
import process
import collateral
import copy
from functools import partial
from scipy.optimize import minimize 
from regression import polyregression
from numpy import zeros, arange, linalg, average, std, dot

class SelfFinancingBSDE(engine.SimulationEngine):
    def __init__(self, vProcess, product,time, snum):
        engine.SimulationEngine.__init__(self, vProcess,time, snum)
        _pnum = self.pnum
        self.pd = product
        self.Z = engine.zeros([snum, _pnum])
        self.Y = engine.zeros(snum)

    # This is the discounted process of
    # self financing strategy
    def generator(self, t, y):
        return zeros(self.snum)
    def targ(self, t, targv, y):
        return sum((y - self.generator(t, y) - targv)**2)
         

    # If it is plain vanila self-financing
    # this function is describing only the terminal
    # payoff. If it is XVA bSDE,
    # this is cashflow + collateral
    def addedvalue(self, t):
        dsf =\
           self.vProcess.listProcess[0].ts.discountfactor(self.time[t]) 
        ret = zeros(self.snum)
        for s in range(0, self.snum):
            ret[s] = self.pd.payoff(self.time[t],self.path[t][s])
        return ret*dsf

    # Backward iteration below, as the name is
    def biteration(self):    
        _tnum = self.tnum
        _snum = self.snum
        _pnum = self.pnum
        # term structure 
        ts = self.vProcess.listProcess[0].ts 

        # discountfactor 
        tdata=zeros(_snum)
        ppath=zeros(_snum)
        
        for t in range(_tnum-1, 0, -1):
            # dsf: discountfactor
            dsf = ts.discountfactor(self.time[t])
            dt = self.time[t]-self.time[t-1]
            # Last path is referred here
            self.Y = self.Y+dsf*self.addedvalue(t)
            # input data for the regrassion in the following step
            ppath=self.path[t-1]
            for p in range(0, _pnum):
                # tdata := y(t+1)*dw(t+1)
                # Be careful about the index t here
                tdata= self.Y * self.randomarray[t,:,p]/dt
                regr = polyregression(ppath, tdata, 2)
                regr.setbasis()
                # Here, self.Z = z(t)
                # Note the path index
                self.Z[:,p]=regr.evalarray(ppath)
            # s iter. set y
            # self.Y := y(t+1)
            tdata = copy.deepcopy(self.Y)
            regr = polyregression(ppath, tdata,2)
            regr.setbasis()
            Yt1 = regr.evalarray(ppath)
            # self.Y :=y(t)
            # initial value
            targfunc = partial(self.targ, t-1, copy.deepcopy(Yt1))
            self.Y = minimize(targfunc,\
                              copy.deepcopy(Yt1),
                              method='nelder-mead',\
                              options={'xtol': 1e-8, 'disp':True}).x

        ###############
        # y(0) and z(0)
        ###############
        # z = vol*xi*s0
        self.z = zeros(_pnum)
        self.y = 0.
        for p in range(0, _pnum):
            self.z[p] = average(self.Y *
                    self.randomarray[0,:,p])/self.time[0]
        self.y = average(self.Y)

##################################################################
class XVA(SelfFinancingBSDE):
    def __init__(self, vProcess, product,time, snum,\
                    rates, Collateral):
        # rates and collateral information
        SelfFinancingBSDE.__init__(self, vProcess,product,time, snum)
        # they are TermStruct classes
        self.rlt = rates['rl']
        self.rbt = rates['rb']
        self.rclt = rates['rcl']
        self.rcbt = rates['rcb']
        self.Collateral = Collateral
        self.count = 0

    # Note that ct = collateral * dsf
    # xva generator 
    def generator(self, t, y):
        rfrate = self.vProcess.listProcess[0].ts.shortrate(self.time[t])
        bl  = self.rlt.shortrate(t) - rfrate
        bb  = self.rbt.shortrate(t) - rfrate
        bcl = self.rclt.shortrate(t) - rfrate
        bcb = self.rcbt.shortrate(t) - rfrate
        # return value
        ret = zeros(self.snum)
        # discounted
        ct = self.Collateral.collateral(\
                t, self.time, self.pd,\
                self.vProcess.listProcess,\
                self.path[t])
        tco = copy.deepcopy(self.vProcess.corr)
        for p in range(0, self.pnum):
            tco[p][p] = tco[p][p]*self.vProcess.listProcess[p].vol

        for s in range(0, self.snum):
            z = sum(dot(linalg.inv(tco.T),self.Z[s]))
            amt = y[s] - ct[s] - z
            if amt >= 0.00000001:
                ret[s] = -bl * amt 
            else:
                ret[s] = -bb * amt

            if ct[s] >= 0.:
                ret[s] = ret[s] - bcl * ct[s]
            else:
                ret[s] = ret[s] - bcb * ct[s]
        return ret  
################################################################
################################################################
for n in range(1, 2):
    #  setting product information
    maturity = 0.2
    timegrid = 5*n
    # simulation information
    dt = maturity / timegrid
    time = arange(dt, maturity+dt, dt)
    snum = 100
    # To set parameters, corr and make the instance
    # of vector process
    xprice = 1.05
    parameters1 ={'initialvalue': 1.,'volatility': 0.2}  
    # xva set up, rates and collateral partial amount
    riskfreerate = 0.02
    rl  = 0.02
    rb  = 0.02
    rcl = 0.02
    rcb = 0.02
    ts   = termstructure.TermStructure(riskfreerate)
    tsl  = termstructure.TermStructure(rl)
    tsb  = termstructure.TermStructure(rb)
    tscl = termstructure.TermStructure(rcl)
    tscb = termstructure.TermStructure(rcb)
    rates = {'rl'  : tsl,\
             'rb'  : tsb,\
             'rcl' : tscl,\
             'rcb' : tscb}
    s1 = process.BaseGBM(parameters1, ts)
    vp = process.VProcess([s1])
    # Product and collateral informatoin
    gamma = 0.0
    #pd  = product.CallForward(maturity, xprice)
    #coll = collateral.CallForwardColl(gamma)
    pd = product.CallOption(maturity, xprice)
    coll = collateral.CallOptionColl(gamma)

    bsde = XVA(vp, pd , time, snum, rates, coll)
    bsde.biteration()
    # result of valuation
    print "-------------------"
    print 'timegrid', 10*n
    print bsde.y, bsde.z/parameters1['volatility']
    print 'count of rl: ', \
            float(bsde.count*100)/float(snum*timegrid),\
            '%'
    print "-------------------"
